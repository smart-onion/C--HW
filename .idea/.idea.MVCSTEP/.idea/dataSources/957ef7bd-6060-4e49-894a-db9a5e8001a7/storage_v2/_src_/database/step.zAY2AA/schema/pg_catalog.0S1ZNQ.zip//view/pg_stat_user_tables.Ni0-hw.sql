create view pg_stat_user_tables
            (relid, schemaname, relname, seq_scan, seq_tup_read, idx_scan, idx_tup_fetch, n_tup_ins, n_tup_upd,
             n_tup_del, n_tup_hot_upd, n_live_tup, n_dead_tup, n_mod_since_analyze, n_ins_since_vacuum, last_vacuum,
             last_autovacuum, last_analyze, last_autoanalyze, vacuum_count, autovacuum_count, analyze_count,
             autoanalyze_count)
as
SELECT pg_stat_all_tables.relid,
       pg_stat_all_tables.schemaname,
       pg_stat_all_tables.relname,
       pg_stat_all_tables.seq_scan,
       pg_stat_all_tables.seq_tup_read,
       pg_stat_all_tables.idx_scan,
       pg_stat_all_tables.idx_tup_fetch,
       pg_stat_all_tables.n_tup_ins,
       pg_stat_all_tables.n_tup_upd,
       pg_stat_all_tables.n_tup_del,
       pg_stat_all_tables.n_tup_hot_upd,
       pg_stat_all_tables.n_live_tup,
       pg_stat_all_tables.n_dead_tup,
       pg_stat_all_tables.n_mod_since_analyze,
       pg_stat_all_tables.n_ins_since_vacuum,
       pg_stat_all_tables.last_vacuum,
       pg_stat_all_tables.last_autovacuum,
       pg_stat_all_tables.last_analyze,
       pg_stat_all_tables.last_autoanalyze,
       pg_stat_all_tables.vacuum_count,
       pg_stat_all_tables.autovacuum_count,
       pg_stat_all_tables.analyze_count,
       pg_stat_all_tables.autoanalyze_count
FROM pg_stat_all_tables
WHERE (pg_stat_all_tables.schemaname <> ALL (ARRAY ['pg_catalog'::name, 'information_schema'::name]))
  AND pg_stat_all_tables.schemaname !~ '^pg_toast'::text;

alter table pg_stat_user_tables
    owner to postgres;

grant select on pg_stat_user_tables to public;

